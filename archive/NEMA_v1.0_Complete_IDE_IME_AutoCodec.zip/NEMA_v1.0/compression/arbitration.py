"""Pure in-memory arbitration model for design testing, NOT deployed Windows IPC."""
from dataclasses import dataclass
@dataclass
class Arbiter:
    ime_present: bool = True
    composition: bool = False
    manual_owner: str | None = None
    revision: int = 0
    def owner(self):
        return self.manual_owner or ('IME_AUTO' if self.ime_present else 'NONE')
    def begin_manual(self, revision):
        if self.composition: raise RuntimeError('composition in progress')
        if revision != self.revision: raise RuntimeError('stale revision')
        if self.manual_owner is not None: raise RuntimeError('manual conversion already active')
        self.manual_owner='IDE_MANUAL'
    def end_manual(self, revision):
        if self.manual_owner!='IDE_MANUAL': raise RuntimeError('no manual lease')
        if revision != self.revision: raise RuntimeError('stale revision')
        self.manual_owner=None
    def commit_ime(self):
        if self.manual_owner: raise RuntimeError('IME auto paused')
        if self.composition: raise RuntimeError('composition not complete')
        self.revision+=1
