#!/usr/bin/env python3
"""NEMA lossless transport CLI. Native fallback uses separate .nema type."""
import argparse,json,sys
from pathlib import Path
from nemat import encode,decode,optimize,choose_transport,candidates

def main():
    ap=argparse.ArgumentParser(description='NEMA/.nemat reference transport')
    ap.add_argument('command',choices=['encode','decode','choose','inspect'])
    ap.add_argument('input');ap.add_argument('output',nargs='?')
    ap.add_argument('--model',help='optional local SentencePiece model; otherwise UTF-8 bytes')
    a=ap.parse_args(); data=Path(a.input).read_bytes().decode('utf-8');scorer=None
    if a.model:
        import sentencepiece as spm
        sp=spm.SentencePieceProcessor(model_file=a.model)
        scorer=lambda s:len(sp.encode(s,out_type=int))
    if a.command=='inspect':
        cs=candidates(data,scorer)
        print(json.dumps({k:{'score':v.score,'bytes':v.out_bytes} for k,v in cs.items()},indent=2,ensure_ascii=False))
        return
    if not a.output:ap.error('output path required')
    if a.command=='decode':
        result=decode(data);kind='nema'
    elif a.command=='choose':
        ch=choose_transport(data,scorer);result=ch.text;kind=('nema' if ch.method=='native' else 'nemat')
        if Path(a.output).suffix!='.'+kind:ap.error(f'choose returned {kind}; output must have .{kind} suffix')
    else:
        ch=optimize(data,scorer);result=ch.text;kind='nemat'
    Path(a.output).write_bytes(result.encode('utf-8'))
    print(json.dumps({'type':kind,'bytes':len(result.encode()),'method':ch.method if a.command in ('choose','encode') else 'decode'}))
if __name__=='__main__':main()
