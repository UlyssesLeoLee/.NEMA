"""NEMA .nemat experimental lossless transport, revision 1.0.

No mutations of native .nema text.  Control lines are interpreted ONLY in
transport mode; the caller MUST know the media type (no guessing).

  \t$N          dictionary manifest: N UTF-8 escaped entries follow
  ^k            dictionary reference, exactly one whole cell
  \\^           literal caret; \\\\ means literal backslash
  \tk           numeric prefix group selector (0-based, first-seen group)
  \tNN v        abbreviated domain header using active prefix group
  \t\\NN        reserved numeric control escaped as literal field

A prefix group is discovered from the *first full domain header* with that
stem; no extra prefix-declaration lines are needed. Header and dictionary
control recognition is stateful and takes precedence over cells.
"""
from __future__ import annotations
from collections import Counter
from dataclasses import dataclass
from typing import Callable
import re

HEADER = re.compile(r'^\t(>?)([A-Za-z][A-Za-z0-9_.-]*) ([1-9][0-9]*)$')
SUFFIX_ID = re.compile(r'^([A-Za-z][A-Za-z0-9_.-]*?)([0-9]+)$')
SELECTOR = re.compile(r'^\t([0-9]+)$')
SHORT = re.compile(r'^\t([0-9]+) ([1-9][0-9]*)$')
DICT_START = re.compile(r'^\t\$([1-9][0-9]*)$')
ALIAS = re.compile(r'^\^([0-9]+)$')
MAX_BYTES = 16 * 1024 * 1024
MAX_PREFIXES = 10000
MAX_DICTIONARY = 64
MAX_VALUE_BYTES = 16 * 1024
MAX_OUTPUT_RATIO = 200

@dataclass(frozen=True)
class Choice:
    method: str
    text: str
    score: int
    in_bytes: int
    out_bytes: int


def split(source: str) -> list[str]:
    if len(source.encode('utf-8')) > MAX_BYTES: raise ValueError('document too large')
    if '\r' in source: raise ValueError('LF required; normalize CRLF before transport')
    if not source.endswith('\n\n\n') or source.endswith('\n\n\n\n'):
        raise ValueError('NEMA requires two terminal empty lines (three final LF)')
    rows=source[:-3].split('\n')
    if any(not row for row in rows): raise ValueError('blank line before EOF')
    return rows


def join(rows: list[str]) -> str:
    return '\n'.join(rows)+'\n\n\n'


def escape_cell(value: str) -> str:
    """Literal caret always is written \\^ in transport, including ^ alone."""
    return value.replace('\\','\\\\').replace('^','\\^')


def unescape_cell(value: str) -> str:
    out=[]; i=0
    while i<len(value):
        c=value[i]
        if c=='^':raise ValueError('literal caret must be written as \\^')
        if c!='\\': out.append(c);i+=1;continue
        if i+1==len(value) or value[i+1] not in ('\\','^'):
            raise ValueError('unsupported transport escape; only \\^ and \\\\ are valid')
        out.append(value[i+1]);i+=2
    return ''.join(out)


def _stem(name: str, graph: str) -> tuple[str,str] | None:
    m=SUFFIX_ID.fullmatch(name)
    return (graph,m.group(1)) if m else None


def _reserved_numeric_line(row: str) -> bool:
    return bool(SELECTOR.fullmatch(row) or SHORT.fullmatch(row))


def encode_prefix_rows(rows: list[str], enabled: bool=True) -> list[str]:
    groups:dict[tuple[str,str],int]={};active:int|None=None;out=[]
    for line in rows:
        m=HEADER.fullmatch(line)
        if m:
            graph,name,rev=m.groups();key=_stem(name,graph)
            if key is None:
                out.append(line);active=None;continue
            if key not in groups:
                if len(groups)>=MAX_PREFIXES:raise ValueError('prefix group limit')
                groups[key]=len(groups);out.append(line);active=groups[key];continue
            g=groups[key]
            suffix=SUFFIX_ID.fullmatch(name).group(2)
            shorthand=('\t'+str(g)+'\n' if active != g else '')+'\t'+suffix+' '+rev
            if enabled and len(shorthand.encode()) < len(line.encode()):
                if active!=g:out.append('\t'+str(g))
                out.append('\t'+suffix+' '+rev);active=g
            else:out.append(line);active=g
        else:
            # A numeric-looking What-cell continuation is legal in native
            # NEMA; reserve that shape in .nemat only, escaping on transport.
            if _reserved_numeric_line(line):out.append('\t\\'+line[1:])
            else:out.append(line)
    return out


def decode_prefix_rows(rows: list[str]) -> list[str]:
    groups:list[tuple[str,str]]=[];seen={};active:int|None=None;out=[]
    for line in rows:
        if line.startswith('\t\\') and _reserved_numeric_line('\t'+line[2:]):
            out.append('\t'+line[2:]);continue
        m=HEADER.fullmatch(line)
        if m:
            graph,name,rev=m.groups();key=_stem(name,graph)
            if key is not None:
                if key not in seen:
                    if len(groups)>=MAX_PREFIXES:raise ValueError('prefix group limit')
                    seen[key]=len(groups);groups.append(key)
                active=seen[key]
            else:active=None
            out.append(line);continue
        m=SELECTOR.fullmatch(line)
        if m:
            idx=int(m.group(1))
            if idx>=len(groups):raise ValueError('unknown prefix selector')
            active=idx;continue
        m=SHORT.fullmatch(line)
        if m:
            if active is None:raise ValueError('short domain without active prefix')
            suffix,rev=m.groups();graph,stem=groups[active]
            out.append('\t'+graph+stem+suffix+' '+rev);continue
        out.append(line)
    return out


def _candidate_cells(source: str) -> list[str]:
    mode='';cells=[]
    for line in split(source):
        m=HEADER.fullmatch(line)
        if m:mode='graph' if m.group(1) else 'other';continue
        for idx,val in enumerate(line.split('\t')):
            if mode=='graph' and idx==0:continue
            if val and 3<=len(val) and len(val.encode())<=MAX_VALUE_BYTES:
                cells.append(val)
    return cells


def dict_apply(rows: list[str], items: list[str]) -> list[str]:
    lookup={v:'^'+str(i) for i,v in enumerate(items)}
    mode='';out=[]
    for row in rows:
        m=HEADER.fullmatch(row)
        if m:mode='graph' if m.group(1) else 'other';out.append(row);continue
        vals=row.split('\t')
        for j,val in enumerate(vals):
            # Graph X0 is an edge expression / node id and NOT a dictionary cell.
            if mode=='graph' and j==0:vals[j]=escape_cell(val)
            else:vals[j]=lookup.get(val,escape_cell(val))
        out.append('\t'.join(vals))
    return out


def dict_restore(rows: list[str], items: list[str]) -> list[str]:
    mode='';out=[]
    for row in rows:
        m=HEADER.fullmatch(row)
        if m:mode='graph' if m.group(1) else 'other';out.append(row);continue
        vals=row.split('\t')
        for j,val in enumerate(vals):
            if mode=='graph' and j==0:vals[j]=unescape_cell(val);continue
            ref=ALIAS.fullmatch(val)
            if ref:
                idx=int(ref.group(1))
                if idx>=len(items):raise ValueError('unknown dictionary reference')
                vals[j]=items[idx]
            else:vals[j]=unescape_cell(val)
        out.append('\t'.join(vals))
    return out


def encode(source: str, dictionary: list[str] | None=None, prefix: bool=True) -> str:
    rows=split(source);dictionary=list(dictionary or [])
    if len(dictionary)>MAX_DICTIONARY or len(set(dictionary))!=len(dictionary):
        raise ValueError('invalid dictionary size or duplicate')
    for item in dictionary:
        if not item or any(x in item for x in '\n\t\r') or len(item.encode())>MAX_VALUE_BYTES:
            raise ValueError('dictionary entry must be one nonempty cell')
    transformed=encode_prefix_rows(dict_apply(rows,dictionary),enabled=prefix)
    manifest=([f'\t${len(dictionary)}']+[escape_cell(v) for v in dictionary]) if dictionary else []
    return join(manifest+transformed)


def decode(source: str) -> str:
    rows=split(source);dictionary=[]
    if rows and (m:=DICT_START.fullmatch(rows[0])):
        count=int(m.group(1))
        if count>MAX_DICTIONARY or len(rows)<count+2:raise ValueError('invalid dictionary count')
        if any(('\t' in v or '\r' in v or not v) for v in rows[1:count+1]):
            raise ValueError('invalid dictionary entry structure')
        dictionary=[unescape_cell(v) for v in rows[1:count+1]]
        if len(set(dictionary))!=count or any(not x for x in dictionary):
            raise ValueError('invalid dictionary entries')
        rows=rows[count+1:]
    raw=join(dict_restore(decode_prefix_rows(rows),dictionary))
    if len(raw.encode())>MAX_BYTES:raise ValueError('output too large')
    if len(raw.encode())>MAX_OUTPUT_RATIO*len(source.encode()):
        raise ValueError('expansion ratio exceeded')
    return raw


def candidates(source: str, scorer:Callable[[str],int]|None=None, max_dictionary:int=12) -> dict[str,Choice]:
    split(source)
    scorer=scorer or (lambda s:len(s.encode('utf-8')))
    count=Counter(_candidate_cells(source))
    allowed=sorted((v for v,n in count.items() if n>=2),key=lambda v:(-count[v]*len(v.encode()),v))[:32]
    outputs={'plain':encode(source,prefix=False),'prefix':encode(source,prefix=True)}
    for pref in (False,True):
        selected=[]; current=encode(source,selected,pref)
        for _ in range(min(max_dictionary,len(allowed))):
            best=None;lowest=scorer(current)
            for val in allowed:
                if val in selected:continue
                trial=encode(source,selected+[val],pref)
                if scorer(trial)<lowest:best=(val,trial);lowest=scorer(trial)
            if best is None:break
            selected.append(best[0]);current=best[1]
        outputs['combined' if pref else 'dictionary']=current
    res={}
    for key,s in outputs.items():
        if decode(s)!=source:raise AssertionError('roundtrip mismatch: '+key)
        res[key]=Choice(key,s,scorer(s),len(source.encode()),len(s.encode()))
    return res


def optimize(source: str, scorer:Callable[[str],int]|None=None) -> Choice:
    variants=candidates(source,scorer)
    return min(variants.values(), key=lambda v:(v.score,v.out_bytes,('plain','prefix','dictionary','combined').index(v.method)))


def choose_transport(source: str, scorer:Callable[[str],int]|None=None) -> Choice:
    """Auto-fallback to native .nema (MIME must identify the selected type)."""
    score=scorer or (lambda s:len(s.encode()))
    best=optimize(source,score)
    native=Choice('native',source,score(source),len(source.encode()),len(source.encode()))
    return min((best,native), key=lambda c:(c.score,c.out_bytes,0 if c.method=='native' else 1))
