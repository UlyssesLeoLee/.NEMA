# IDE1.0 — 基本设计 / 详细设计

## Rust 插件/内核分工
1. `crates/nema-codec`（建议新增）：纯 Rust、无 GUI 依赖；语法版本、编码器、解码器、候选、token cost adapter、保真与限额。
2. `ide-kernel-core`：NEMA 文档会话、领域索引、dirty buffer SHA、领域 CAS、IME 转换事件合并。
3. `ide-shell` / `ide-shell-web` / `ide-shell-desktop`：消费结构化渲染 AST，左侧编辑原文，右侧 5W1H / Table / Graph / 压缩候选视图；只有用户**点击转换**才向协调器请求手动优先权。
4. `ide-cli`：`nema encode/decode/inspect/validate/bench` 的可脚本化入口；输入输出媒体类型必须明确。

## 核心接口
```rust
pub enum MediaType { Nema, Nemat }
pub enum ConvertOwner { ImeAuto, IdeManual }
pub struct DocumentRev { pub path: String, pub sha256: [u8;32], pub domain_revision: u64 }
pub struct ConversionOption { pub method: String, pub tokens: Option<u64>, pub bytes: usize }
pub trait TokenCounter { fn count(&self, input: &str) -> Result<usize, TokenError>; }
pub fn choose_transport(src: &str, counter: Option<&dyn TokenCounter>) -> Result<ConversionOption, Error>;
```
Rust 最终接口名称可调，但 bytes/token、媒体类型、来源、SHA 与错误码不得缺失。

## UI 交互
- 打开文件：展示 canonical；IME 活跃时状态显示“IME auto owns conversion”；无数据传输时不生成 `.nemat`。
- 用户点击转换：发 `ManualConvert(document, base_sha256)`，撤销 IME 同基线 pending，收集词典、排序候选并独立验证；展示预览后可保存独立传输文件。
- IME 发 `Converted`：IDE 检查 SHA、协议及 IME owner，再刷新 token 面板；不能将 `.nemat` 当编辑缓冲区写回。
- 文件变更后丢弃旧 token 统计；同领域两个 Agent 冲突显示差异并要求 CAS 重试。
- 真实 API Key、password、密钥引用的原始内容不可送往跨工作区共享字典；启用敏感扫描与安全日志脱敏。

## WBS
P0: 实现 codec crate 与测试向量 → 解析器往返 → CLI → 保存/撤销; P1: IME/IDE arbiter → 手动优先协议 → token 面板; P2: Graph 可视化与领域增量提交 → Playwright UI; P3: 模型 tokenizer 实测和压力测试。每阶段单独设计/测试提交，遵守现有 IDE 项目质量流程。
