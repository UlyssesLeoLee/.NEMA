# IDE1.0 — UT / IT / ST 测试设计

| ID | 层 | 测试内容 | 预期结果 |
|---|---|---|---|
| IDE-UT-01 | UT | Tab、双空行、Graph 边、UTF-8、^ 转义 | 解码与源字节一致 |
| IDE-UT-02 | UT | `TAB$2` 词典，原文 `$0` | 只有传输首行声明字典，原文不丢失 |
| IDE-UT-03 | UT | `TAB0` 数字前缀与正文数字 | 前缀有效、正文原样/按需保护 |
| IDE-UT-04 | UT | 反向边 `B<Z<C` | 图方向为 C→B |
| IDE-IT-01 | IT | IDE 与 IME 同时监听 | 只有 IME auto 自动生成产物 |
| IDE-IT-02 | IT | IDE 手动点击转换 | 抢占 IME 未提交同基线任务 |
| IDE-IT-03 | IT | 外部工作区修改原文 | 旧 SHA 转换失败，源文件不变 |
| IDE-IT-04 | IT | Graph Edge 同时提交 | 同一 ID 冲突显式拒绝 |
| IDE-ST-01 | ST | 千行表格、600 Edge、混合语言 | UI 可取消、不会冻结或溢出 |
| IDE-ST-02 | ST | 无 tokenizer / 成本高 | 明示字节代理 / 自动回退 native |
| IDE-ST-03 | ST | 关闭再打开文件 | 原生文件字节与领域版本不变 |
| IDE-ST-04 | ST | 断电/写文件失败模拟 | 临时产物原子替换或回滚 |

本包 Python 测试覆盖编码核心及所有者模型；IDE Rust/Playwright 集成用例尚待在 IDE1.0 仓库实施，不宣称已经通过。
