# IDE1.0 — NEMA 自动转换接入要件定义

依据已查看的仓库 `UlyssesLeoLee/IDE1.0`（Rust workspace，`crates/ide-kernel-core`、`ide-shell`、`ide-shell-web`、`ide-shell-desktop`、`ide-cli`）。仅给出未来开发交付计划，**没有修改 GitHub 仓库**。

## 用户功能
- 打开 `.nema` 后提供原文 / 5W1H / Table / Node–Edge / 压缩预览四种可切换视图；真正代码文件保留原有语言解析器。
- 手动“转换并验证”按钮：比较原生、仅字典、仅前缀、组合的目标模型 Token；显示输入/输出 Token、字节、词典项、消歧错误及能否无损解码。
- 自动提炼词典（仅完整重复单元格）、通过首个完整领域 ID 自动索引数字前缀；允许查看/禁用候选项及锁定共享字典版本。支持跨域局部读取、增量更新和 CAS。
- **IME1.0 在场且活跃时由 IME 自动编码，IDE 只接收状态与手动覆盖；不能因用户输入停顿而与 IME 重复转换。**
- 保留 `.nema` 作为 canonical 编辑对象，`.nemat` 作为可选传输产物；转换失败不损坏原始文件。

## 安全/非功能
- 本地优先，无默认外传；敏感值不进入字典，适用用户工作区同意与密钥保护。
- 显示模型 tokenizer 来源及“非官方估算”标签；无 tokenizer 时按字节评估，不称之为 API Token。
- 大文件后台计算支持取消、不阻塞编辑，防止重入、旧快照覆盖、Graph Edge 引用错配。
