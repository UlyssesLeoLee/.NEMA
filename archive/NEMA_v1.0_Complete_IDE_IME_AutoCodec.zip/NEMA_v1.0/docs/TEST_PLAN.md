# NEMA v1.0 测试设计（UT / IT / ST / UAT）

## UT
1. `$0` 开头普通 Who/What 原文在有 `Tab+$N` 词典时不混淆。
2. 字面量 `^`, `^0`, `\^`, `\\` 往返无损；非法反斜杠转义拒绝。
3. 纯数字字段、Tab+数字 What 续行、补零数字后缀的前缀碰撞处理。
4. 空字典、短内容、高熵输入不应强制压缩；秘密字段默认不纳入字典。
5. 日语助词及标点、英文缩约、Table 多行单元格、Graph 正反向边与自循环不变形。
6. 字典条目限制、文件大小、解压比率、错误清单、非完整尾标记均明确报错。

## IT
1. Rust 核心和参考 Python codec 对相同 fixtures 产生相同语义（最终压缩字节可由确定性 tie-breaker 约束）。
2. IDE 手动转换与 IME 自动转换共存时：单写入者、IME 优先、版本 CAS、SHA-256 对照。
3. IME composition 中 IDE 手动请求 → 等待/拒绝；组合完成后重试。
4. Agent 同时编辑不同领域并发成功；同领域旧版本 CAS 拒绝。
5. 字典发生变化时，旧 `.nemat` 不可错误地引用新词典。

## ST / UAT
1. Windows 11 + 真实 TSF + IDE Shell + VS Code；中文/日文/英文 IME 组合输入不被中断。
2. 原生文件 / 压缩传输互转；离线、权限拒绝、工作区切换、CPU 负荷、内存峰值。
3. 压缩收益对比基准：原生 NEMA、紧凑 YAML、极简位置 YAML、JSON、字典压缩传输；保留原文与目标模型 Token 真实计数，不删失败样本。
4. AI 消费侧任务正确率：值逐字保留、Topological orientation、领域版本、测试后回滚。
5. IME 优先自动、IDE 手动接管、UNDO 后不重新覆盖、切换不同 tokenizer。

## 验收门槛
- 精确字节往返 100%，静默数据覆盖 0。
- 转换结果 Token 预算净收益为正才发送 `.nemat`；否则采用 `.nema`。
- 官方 GPT/Claude/Gemini tokenizer 及真实端到端 AI 任务成本需另行验证；本交付本地 SentencePiece 不代表官方账单。
