# IME1.0 — NEMA 输入期间智能压缩接入详细设计

**目标项目**：`UlyssesLeoLee/IME1.0`。仓库现有 `01_Source/crates/pime-core`、`pime-tsf`、`pime-ipc`、`pime-ai-worker`，以及 `01_Source/editor-bridges/vscode`。Windows TSF 的完整实际注册与输入法运行验收尚未完成；本文件是**待实现设计**。

## 角色与默认策略
- IME1.0 是优先转换器：当前用户有权限、处于 `.nema` 已授权编辑区并且完成 IME composition commit 后，自动解析并优化候选传输编码。
- IDE1.0 即使同时安装也**不自动转换**；只有 IDE 用户明确点击“转换”按钮时由 IDE 临时接管，随后恢复 IME 优先。
- “自动转换”默认**更新候选 `.nemat` 或传输队列，不擅自把原始编辑文本替换成带控制字符的压缩文本**。保留原始 `.nema` 缓冲区供用户编辑。
- 对无法确认焦点、文档类型或编辑器未声明安全接口的输入框，仅提供普通文本输入，不监控、不转换密码框。

## 输入状态机
`DISABLED → ELIGIBLE → COMPOSING → COMMITTED → DEBOUNCING → ENCODING → READY → SENT / FALLBACK`。
- 触发：TSF `OnEndEdit` / 编辑器桥接的文本提交事件；必须在组合输入结束后运行，不干扰日语假名、韩文组合或候选窗。
- 多次快速编辑：取消旧任务并用缓冲区 revision 丢弃过期结果；不用键盘每击即时重压缩整个文档。
- 字典由 `(document_id, snapshot_hash)` 缓存。增量更新受影响领域，异步或工作线程计算并设置 token 预算、延迟预算。
- 取消或不可用时继续原始输入，不阻塞输入法主线程；长文本由 IDE 内核异步编译传输。

## 字典自动提炼与设置
- 默认建议 `AUTO`：候选词必须是**重复、非敏感、完整单元格**；逐一评估字典清单本身与引用成本，只有净收益时才采纳。
- 用户设置 `AUTO / MANUAL / DISABLED`，可在配置里固定、排除或清除单元词典；仅作用于已授权的 NEMA 工作区。
- 自动从 `Task001` 之类领域 ID 提炼稳定前缀组，**数字独占 Tab 行**切组；共享字典只在压缩传输封包首行使用 `Tab+$N`。
- `\^` 为字面量 caret，`\\` 为字面量反斜杠；其他普通 `$`、数字、APIKey 原样，不对正文误解析。
- 字典可跨进程由共享 Rust codec 维护，但安全地按文档版本隔离；不可从用户实际密码自动学习或持久化到不安全日志。

## 推荐集成接口
- `pime-core` 增加低延迟 NEMA 编辑上下文识别及状态机；`pime-tsf` 只报告 composition lifecycle。
- `pime-ipc` 增加 `ContextProbe`, `ConvertRequest`, `ConvertResult`, `CancelRevision`, `ManualOwnerOverride`；协议信息含 `document_id`, `revision`, `sha256`, `codec_version`, `chosen_format`, `tokenizer_id`, `request_id`。
- `pime-ai-worker` 或单独 `nema-codec` worker 执行 tokenizer/字典搜索，所有不受信内容限额；`editor-bridges/vscode` 提供已授权的真实文档快照和明确扩展名。
- IPC 不得承载明文密码；机密检测失败时保守回退原文且不发送到未经允许的模型端点。

## 双安装竞争测试
IME 在 `COMPOSING` 时 IDE 手动转换必须等待或返回明确“正在输入”错误；在 `READY` 时 IDE 手动转换取得独占锁，IME 所有过期转换取消。提交后重新比较版本与散列，防止两个 Agent 或两个编辑器窗口对同一文档写回冲突。

## UI 可见性
候选窗/设置页显示“自动提炼词典”“当前净节省率”“排除该值”“恢复原文”“转换权限：IME 优先”；显示的 Token 节省率必须注明模型或本地代理 tokenizer 以及估算/实测状态。不要在普通文字输入中弹出压缩工具 UI。

## 必须先通过的验收
Windows VM 上 TSF 组合输入、日文/英文混输、撤销/重做、VS Code 编辑器桥接、与 IDE 手动抢占、两进程 IPC、失焦密码框、断网及 30 分钟长稳。**以上属于计划测试，未宣称在本交付中完成。**
