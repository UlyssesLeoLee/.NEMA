# IME1.0 — 基本设计 / 详细设计

## 部署和复用
- `pime-core`: 引用 Rust `nema-codec` 核心库（独立 crate 通过 Git/本地依赖），提供 `suggest_dictionary`, `choose_transport`, `validate`, `escape_literal`；不再开发第二套正则/压缩算法。
- `pime-tsf`: 负责 Windows TSF composition 与 commit 事件，只输出候选、插入原生字符、触发协议；**不在 TSF 回调同步运行大文档压缩**。
- `pime-ipc`: 使用用户级本地命名管道连接 IDE 会话/转换协调器，消息含 document ID、base hash、媒体类型、请求号、deadline 和 lease owner；恶意进程不能无授权提交。
- `pime-ai-worker`: 默认只使用确定性词频+TokenCounter；AI 功能明确用户同意后异步建议分类，敏感值扫描，禁止生成未验证的 `^k`。
- `editor-bridges/vscode`: 收集编辑器语言、当前字段、领域号、dirty SHA、光标及焦点，用户只看到人类友好 NEMA，转换文件由独立路径存储。

## 自动提炼状态机
1. IME 启用且焦点位于 `.nema` → 获取编辑器提供的 canonical snapshot（不可绕过授权读取其他窗口）。
2. 用户 commit 一段候选 → 防抖、检查文档是否有效、生成该文档的共享字典候选和前缀组。
3. 分词器可用时用它测真实本地 token count；否则字节数代理，绝不标为目标模型 Token。
4. 自动比较 native / prefix / dictionary / combined，验证逐字节往返，负收益选择 native。
5. 申请 `ImeAuto` lease，确认没有 IDE manual 同基线抢占后写**传输缓存/发送输出**；不改 canonical buffer。
6. 如 IDE 点击手动转换：撤销 IME pending、所有者变为 IdeManual，IME 只显示新预览，不再次自动写入。
7. 写前再次验证源 SHA + 领域修订；过期结果拒绝提交并标注 stale，后续有效 commit 才重试。

## 设置项（默认）
- `nema.enabled=true`（仅 `.nema`）；`nema.auto_owner="IME1.0"`；`nema.ime_debounce_ms=250`；`nema.max_dictionary=12`；`nema.max_input_bytes=16777216`；`nema.fallback_to_native=true`；`nema.send_sensitive=false`。
- `nema.tokenizer_id`: 可以为空；为空则 token 成本显示“unknown”，使用字节代理。
- `nema.shared_scope="document"`；跨进程缓存用 `document_sha+codec_version+tokenizer_id` 作键。

## 误输入场景
- `$0` 开头的普通 What 保留原文；传输字典只能在 `TAB$N` manifest 中声明。
- 原样 `^0` 经过 `\\^0` 可无损还原；输入法用户通常无需手工输入转义，编码器负责。
- 纯数字或 `TAB02 1` 的 What 续行仅在传输层冲突时使用保留反斜杠保护；**不能通过把所有数字一律看成前缀**破坏数据。
