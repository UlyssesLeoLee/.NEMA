# IME1.0 — UT / IT / ST 测试设计

| ID | 层 | 场景 | 期望 |
|---|---|---|---|
| IME-UT-01 | UT | 光标处普通 `$value` | 不解释为共享字典 |
| IME-UT-02 | UT | 字面量 `^0` / 反斜杠 | `\\^0` 与 `\\\\` 无损回转 |
| IME-UT-03 | UT | Graph Edge / 日语助词 / HTTP/2 | 保持原始 Tab、字符、大小写 |
| IME-UT-04 | UT | 新增重复值 | 提取共享字典候选，Token 净收益筛选 |
| IME-IT-01 | IT | composition 尚未 commit | 不触发转换 |
| IME-IT-02 | IT | commit 后防抖与取消 | 只执行最后有效任务 |
| IME-IT-03 | IT | IME 与 IDE 同时激活 | IME 自动优先；IDE 非手动不触发 |
| IME-IT-04 | IT | 用户点击 IDE 手动转换 | IDE 抢占未提交 IME 任务 |
| IME-IT-05 | IT | IME 写入前文档改变 | CAS 拒绝旧转换 |
| IME-ST-01 | ST | 高速连续键入 30 分钟 | 输入法候选与 TSF 不阻塞 |
| IME-ST-02 | ST | 断开 IDE、命名管道断连 | 原文安全、回退不重入 |
| IME-ST-03 | ST | 多屏/焦点切换/注销 | 不跨窗口使用错词典 |
| IME-ST-04 | ST | 用户敏感口令 | 不进入词典、日志和远端模型 |

当前仅有可运行编码器与模拟所有权的 Python 回归测试；Windows TSF 和 IDE 真机联调尚未执行。
