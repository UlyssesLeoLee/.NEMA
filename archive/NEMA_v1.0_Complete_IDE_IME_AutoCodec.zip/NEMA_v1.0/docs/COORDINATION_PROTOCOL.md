# IDE1.0 / IME1.0 双工具协同契约

## 单写入者原则
- 同时安装：IME1.0 拥有自动转换权；IDE1.0 只有明确点击按钮时获取短时人工转换权。
- 读写分离：编辑器唯一权威副本为 `.nema`；`.nemat` 是由指定版本衍生的可重建传输缓存。任何 UI 均不可在未经授权时覆盖文档。
- 转换提交前必须比较源版本和 SHA-256；自动与手动任务均有独立 request_id，重试幂等。

## 状态转移
`NONE → IME_AUTO → IDE_MANUAL → IME_AUTO`。IME 禁用或无上下文时为 NONE；IDE 手动仍可请求一次性转换。Windows 输入法组合阶段不是可抢占的文本提交点。

## 最小消息实例（JSON IPC，不是 NEMA 文件内容）
```json
{"request_id":"req-001","document_id":"worktree://project/docs/a.nema","revision":8,"source_sha256":"sha256-of-source","codec_version":"1.0-experimental","owner":"IME_AUTO","action":"convert","tokenizer_id":"neutral_bpe","output":"nemat-or-native"}
```

## 故障恢复
进程崩溃释放租约（lease timeout + fencing token），旧结果必须因 buffer_version 过期拒绝；避免轮询输入法敏感上下文；各组件以 SHA-256/内容长度验证相同源，自动转换不可改变原始文档。
