# NEMA 共享协议与多 Agent 交接

## 版本化消息模型（产品接入设计，非已集成协议）
```json
{"protocol":"nema-transport/1","document":"repo://docs/tasks.nema","base_sha256":"<hex>","domain":"TaskLogin002","domain_revision":1,"source":"IME1.0","media_type":"application/x-nemat","dictionary_scope":"document","dictionary_sha256":"<hex>","payload_ref":"<local opaque ref>"}
```
载荷只可为已验证的 `.nema` 或 `.nemat`；压缩语法不承担授权、命令执行和全局事务语义。解码应在受限进程完成，校验媒体类型、扩张限额、哈希、领域版本，再 CAS 提交。

## 自动转换的唯一所有者
- 默认 **IME1.0 拥有自动转换权**：当 IME 活跃、文档有效、输入已完成并越过明确提交边界后执行，本地无损验证后通知 IDE 刷新可视化；不是每击键转换。
- IDE1.0 **只在用户主动点击“转换”** 时获得本轮最高优先级，取消/抢占 IME 对同一 `document + base_sha256` 的未提交自动转换。
- 如果 IME 没有安装、未启用、无文档权限，IDE 可以提供手动转换，但**不擅自启用 IDE 自动转换**，避免重复写文件。
- 同一工作文档同一基线只允许一个提交者。所有者变更要取消旧任务并要求新一轮 CAS。所有生成的传输文件都可以暂存，但绝不允许两个通道都自动写回同一源文件。

## 状态机
`Idle → Editing → Committed → Analyzing → Encoding → Verified → ReadyToSend / FallbackNative`。
IME 从 `Committed` 自动进入 Analyzing；IDE 按钮在任意未提交状态可进入 `ManualOverride`，使 IME pending 任务失效；`Verified` 之后仍要持有匹配的 base SHA 和修订版本才可发布。

## 职责边界
IDE 核心维护 canonical .nema 与渲染；IME 提供输入完成事件、候选和自动转换建议；公共 `nema-codec` 负责词典、prefix、转义及 decode；独立事务协调器负责乐观锁/取消与成果仲裁。密钥绝不进入字典候选或日志。
