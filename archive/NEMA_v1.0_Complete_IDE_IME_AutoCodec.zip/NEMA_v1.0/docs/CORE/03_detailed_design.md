# NEMA v1.0 — 详细设计与语法优先级

## 语法（本地参考实现实际支持）
- 原生领域头：`TAB ID SPACE revision`；Graph `TAB >ID SPACE revision`。
- 传输字典清单：文件首行 `TAB $N`，其后恰好 N 行为**单格**条目；这些条目的 `^` 和反斜杠也须转义。声明仅在文件开头生效。
- 传输前缀组选择：`TAB K`（非负十进制整数，唯一占一行）；缩短领域头：`TAB suffix SPACE revision`。前缀来源于该文件此前的完整领域头；ID 的尾部必须是数字。
- 单元格字典引用：独占单元格的 `^K`；其他情况一律原样，除 `\^` 与 `\\` 作为保留字面转义。所有未知反斜杠转义拒绝解码。
- 普通 `$value`、`$0`、`$$` 在原生 5W1H/Table/Graph 正文中不特殊；只有文档首行的 `TAB$N` 才触发字典。
- 原生 `TAB 42` 或 `TAB 02 1` 这类 What 纵向意群在 `.nemat` 内与数字前缀冲突，**只在这一冲突发生时**添加保留转义 `TAB\\42` 或 `TAB\\02 1`；反向还原时恢复原样。这是无损的必要例外。

## 示例
压缩前：
```text
\tTaskLogin001 1
Argo\tReview\tNow\tAuthGateway\tWrite\tHTTP/2
\tTaskLogin002 1
Claude\tReview\tNow\tAuthGateway\tAudit\tHTTP/2
```
压缩后示意（`\\t` 在文档中用文字标记真实 Tab；真实文件存 U+0009）：
```text
\t$2
AuthGateway
HTTP/2
\tTaskLogin001 1
Argo\tReview\tNow\t^0\tWrite\t^1
\t002 1
Claude\tReview\tNow\t^0\tAudit\t^1
```
- `TaskLogin001` 首次出现保留完整 ID，之后的 `002` 依赖它；没有每行显式前缀字符串。
- 如果真实字面文本为 `^0`，压缩后必须是 `\^0`；字面 `\\` 的转义为 `\\\\`。这不是一般语义片段的转义，只用于保证压缩协议无损。
- 任何压缩结果都必须先通过编解码逐字节校验，再交给 IDE 或 Agent。无收益输出原始 `.nema`。

## 资源与安全边界
最大原始/解码大小 16MiB；最多 10,000 前缀组、64 词典项、单值 16KiB、扩张比不超过 200。拒绝非法媒体类型、非法引用、残缺 EOF、无效 UTF-8。安全的外部 API Key 用引用而非明文。

## Rust 迁移
参考 API：`parse_native(&str)->Result<Canonical>`, `extract_dictionary(&Canonical, Budget)->Vec<String>`, `encode_transport(&Canonical,&Config)->Result<Vec<u8>>`, `decode_transport(&[u8])->Result<Canonical>`, `choose(&Canonical,&dyn TokenCounter)->Choice`, `commit(CAS)->Result<()>`。用无额外系统依赖的 Rust crate `nema-codec` 实现纯算法，前端/IME/Agent 复用统一测试向量。当前仅有可执行 Python 参考实现，Rust crate 是后续实施设计。
