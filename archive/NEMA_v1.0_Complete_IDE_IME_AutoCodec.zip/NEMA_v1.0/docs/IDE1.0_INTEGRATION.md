# IDE1.0 — NEMA 自动提炼、转换与可视化接入详细设计

**目标项目**：`UlyssesLeoLee/IDE1.0`；已核对仓库包含 `crates/ide-kernel-core`、`crates/ide-shell`、`crates/ide-shell-web`、`crates/ide-shell-desktop` 与 `crates/editcore`。以下路径为**开发目标**，非已落地源码。最终路径需结合工作区现状确认。

## 需求与功能边界
- 识别 `.nema`，按 5W1H / Table / Graph 三模式渲染；保留 Tab、纵向意群、方向和 Edge 的实际内容。
- 在预览、保存或用户点击“转换”时，从**完整已验证的普通单元格**统计频次，建立共享字典；对 ID 自动提炼词根、分配纯数字索引；生成候选 `.nemat`。
- 允许用户锁定或排除字典词条、选择模型、调整阈值、查看每次收益及可撤销的转换差异；不把压缩文本直接回写到代码缓冲区。
- **IME1.0 同时存在：默认只读校验与显示，禁止自动转换；仅用户手动点击 IDE1.0 的转换按钮时触发一次性接管。**
- 必须使用共享 Rust codec（建议 workspace crate `nema-codec`），不能在 TypeScript 或编辑器 Shell 重新实现一套不一致的压缩算法。

## 目标分层
1. `crates/nema-codec`：`parse / render / encode / decode / optimize / token_score / validate`。以纯 Rust 实现，C ABI / JSON IPC 供外部产品调用。
2. `crates/ide-kernel-core` 或领域服务：保存层，负责快照、Schema、内容散列、领域版本 CAS、缓存以及事务。
3. `crates/ide-shell-web`、`ide-shell-desktop` 和 Shell：原始 / 压缩 / 人类渲染三视图，节省率面板、字典预览、显式“转换”按钮。
4. `editcore`：仅在用户确认后的事务内切换目标编辑文档，原生 `.nema` 保持单一真实源；`.nemat` 导出到侧车文件或 API 请求体。

## 自动字典提炼算法
- 仅统计经过确定性 parser 校验的整格值，至少出现 2 次；Graph X0、领域标识和含敏感凭证的字段不参与。
- 在模型 tokenizer 可用时，逐次选择使总 Token 降低最多的词条，**把 `\t$N` 清单和每个索引引用的成本一起算入**。不可仅按字符长度估算收益。
- 每个转换快照的词典只属于当前传输封包；基于稳定语义排序生成词条，防止两个 Agent 对不同版本使用同一索引。
- 前缀组按完整领域 ID 第一次出现的词根编号；选组写 `\t0`、`\t1`，后续领域头写数字尾号。选择后必须完整解码并比较 SHA-256。
- 未提供目标 tokenizer 时仅计算字节候选并明确标注为“字节代理优化”，不得宣称模型 Token 减少。

## 同 IME 的优先权协议
- 双方通过受控本地 IPC `GetOwner(document_id, buffer_version)` 进行自动转换权协商；权限枚举 `IME_AUTO / IDE_MANUAL / NONE`。
- IME 安装且当前编辑器已授权、处于可转换的 `.nema` 上下文时，owner = IME_AUTO。IDE 无自动监听式写回。
- IDE 手动按钮获取一次性事务令牌，若 IME 正在组合输入则等待提交完成或拒绝；手动事务期间暂停 IME 自动转换；完成/撤销后释放，自动权归 IME。
- 每个转换使用 `(document_id, revision, content_hash, request_id)` 幂等键；冲突则报告并重新读取，绝不覆盖后写内容。
- IME 未装、未授予权限或暂时不可用：IDE **也不自行开启自动转换**，只保持手动转换，除非用户专门开启 IDE 自动模式。

## 交互验收
`Open .nema → Preview dictionary candidates → (IME installed: no IDE auto) → Click Convert → Compare source/transport → Confirm → Export .nemat → Undo`。
支持版本切换、离线、词典被强制锁定、Graph 环、自循环、多 Agent 修改同一领域、用户中断、IME 组合输入状态、敏感内容、Token 预算不足时原文回退。图形从 Node-Edge 关系生成，源代码正文不进入 NEMA 编码器。

## 验收指标
- 100% 字节无损 round-trip（测试语料）、不丢 Tab/空行/标点/大小写；本地 tokenizer 成本展示可复现。
- 手动按钮不会造成 IME 双重转换、0 静默冲突覆盖；格式回退不改变内容。
- 日志不包含词典明文秘密、完整 API Key 或用户密码；不得自动上传未获授权的用户工作区内容。
- UT/IT/ST/UAT：参见 `TEST_PLAN.md`，实现前不声称通过 Windows 编辑器验收。
