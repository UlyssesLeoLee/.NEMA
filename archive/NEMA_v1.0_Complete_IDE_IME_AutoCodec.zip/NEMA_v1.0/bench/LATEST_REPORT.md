# NEMA v1.0 最新压缩实测

执行环境：Python 3.13 + SentencePiece 0.2.1，使用本地 whitespace-preserving BPE 与 Unigram 模型。它们不是 GPT / Claude / Gemini 官方 tokenizer。

| 样本 | 原始 BPE | 选择后 BPE | BPE 节省 | Unigram 节省 | 选择模式 |
|---|---:|---:|---:|---:|---|
| tasks_en_1 | 28 | 28 | 0.00% | 0.00% | native |
| tasks_en_60 | 1,773 | 1,464 | 17.43% | 30.35% | combined |
| tasks_ja_compact_60 | 2,163 | 1,235 | 42.90% | 52.62% | combined |
| tasks_ja_60 | 2,163 | 1,235 | 42.90% | 52.62% | combined |
| table_compact_1000 | 22,223 | 16,262 | 26.82% | 51.43% | dictionary |
| table_1000 | 22,223 | 16,262 | 26.82% | 51.43% | dictionary |
| graph_120_600 | 16,860 | 11,051 | 34.45% | 38.72% | dictionary |
| entropy_table_140 | 8,294 | 8,294 | 0.00% | 0.00% | native |
| twelve_agents | 347 | 287 | 17.29% | 35.34% | combined |

## 字节实测

`samples/twelve_agents.nema`：780 B → `samples/twelve_agents.nemat`：396 B（节省 49.23%），本地 BPE：347 → 287（节省 17.29%）。全部结果由 `bench/bench.py` 实际运行产生。

## 限制及不利样本

- `entropy_table_140` 的本地 BPE 节省为 0%，采用原生回退，不强行压缩。
- 小型单领域样本也是 0%，词典头、引用开销可能超过收益。
- 字典生成属于 Python 参考算法；Rust/Windows 的 IDE/IME 集成仍是设计，不是已实现功能。
- 对比基准为 NEMA 原生与 NEMA 压缩传输。要得到相对 YAML 的同集公平节省率，必须构建语义一致、同样无损的 YAML 参照；之前报告中不同语料的 YAML 数字不能直接作为这里的节省率。
- Token 成本应计入模型的解析指令、反序列化调用与纠错重试；本基准只计入文件输入。

## 核验

运行 `python -m unittest discover -s tests -v` 和 `python bench/bench.py`；样品应严格无损解码。
