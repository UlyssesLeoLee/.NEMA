#!/usr/bin/env python3
"""Honest local tokenizer benchmark; native vs experimental transport.
The corpus and tokenizer do NOT represent GPT, Claude or Gemini token bills.
"""
from pathlib import Path
import sys,json,gzip,shutil
import sentencepiece as spm
ROOT=Path(__file__).resolve().parents[1]; BASE=ROOT/'bench'
sys.path.insert(0,str(ROOT/'compression'))
from nemat import choose_transport,optimize,decode
names=['tasks_en_1','tasks_en_60','tasks_ja_compact_60','tasks_ja_60','table_compact_1000','table_1000','graph_120_600','entropy_table_140']
sp={n:spm.SentencePieceProcessor(model_file=str(BASE/'models'/f'neutral_{n}.model')) for n in ['bpe','unigram']}
for model in sp.values():
    for v in ('\tTa1 1','\t\t\t\t\tTa1 1','Who\tWhat\nWhy','\\^ ^0 \t$1'):
        assert model.decode(model.encode(v))==v,'tokenizer normalization is lossy'

def measure(src, stem):
    bytes_in=len(src.encode());gzip_in=len(gzip.compress(src.encode(),mtime=0));r={'scenario':stem,'native_bytes':bytes_in,'gzip_native':gzip_in}
    for name,model in sp.items():
        score=lambda text:len(model.encode(text,out_type=int))
        best=choose_transport(src,score)
        if best.method!='native':assert decode(best.text)==src
        t0=score(src);t1=best.score
        r[name]={'native_tokens':t0,'selected_tokens':t1,'method':best.method,'saving_percent':round(100*(t0-t1)/t0,2),'selected_bytes':best.out_bytes,'gzip_selected':len(gzip.compress(best.text.encode(),mtime=0))}
    return r

result=[]
for stem in names:
    fixture=BASE/'fixtures'/f'{stem}.nema'
    if not fixture.exists():continue
    s=fixture.read_bytes().decode('utf-8')
    result.append(measure(s,stem))
s=(ROOT/'samples'/'twelve_agents.nema').read_bytes().decode('utf-8')
result.append(measure(s,'twelve_agents'))
(BASE/'RESULTS.json').write_text(json.dumps({'models':{'bpe':'local SentencePiece neutral_bpe (whitespace preserving)','unigram':'local SentencePiece neutral_unigram (whitespace preserving)'},'results':result},indent=2,ensure_ascii=False)+'\n')
for row in result:
 print(row['scenario'],row['native_bytes'],row['bpe']['native_tokens'],row['bpe']['selected_tokens'],row['bpe']['method'],row['bpe']['saving_percent'])
