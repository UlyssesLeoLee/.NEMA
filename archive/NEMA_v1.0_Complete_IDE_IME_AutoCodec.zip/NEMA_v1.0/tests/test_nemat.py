import unittest,sys,random,string
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'compression'))
from nemat import encode,decode,candidates,optimize,choose_transport,escape_cell,unescape_cell
END='\n\n\n'
def doc(s):return s+END

class CodecTest(unittest.TestCase):
    def roundtrip(self,src,dictionary=(),prefix=True):
        enc=encode(src,list(dictionary),prefix)
        self.assertEqual(decode(enc),src)
        return enc
    def test_samples_and_candidates(self):
        for sample in sorted((ROOT/'samples').glob('*.nema')):
            with self.subTest(sample=sample.name):
                raw=sample.read_bytes().decode()
                self.roundtrip(raw,prefix=False)
                self.roundtrip(raw,prefix=True)
                for choice in candidates(raw).values():self.assertEqual(decode(choice.text),raw)
    def test_manifest_tab_dollar_not_dollar_in_who(self):
        src=doc('\tTask001 1\nArgo\t$value\t$0\tAuthGateway\n\tTask002 1\nClaude\t$APIKEY\t$$0\tAuthGateway')
        val=self.roundtrip(src,['AuthGateway'])
        self.assertTrue(val.startswith('\t$1\nAuthGateway\n'))
        self.assertIn('$value',val)
        self.assertIn('$$0',val)
        self.assertIn('^0',val)
    def test_caret_literal_backslash_escape(self):
        src=doc('\tTa1 1\n^\t^0\tA^B\tC\\^D\t\\\t^^\n\tTa2 1\n^0\t^\tC\\^D')
        wire=self.roundtrip(src,['^0','C\\^D'])
        self.assertIn('\\^',wire)
        self.assertIn('^0',wire)
        self.assertIn('\\\\',wire)
        self.assertEqual(unescape_cell(escape_cell(r'^\^x')),r'^\^x')
    def test_graph_edge_caret(self):
        self.roundtrip(doc('\t>Gauth1 1\nA\tNode\tOriginal\nB\tNode\tOk\nA>X>B\tReads\tA^B and HTTP/2\n\t\tA\\^B'), ['Reads'])
    def test_numeric_prefix_selector(self):
        src=doc('\tTask001 1\nAgent\tReview\n\tEdge01 1\nAgent\tWrite\n\tTask002 2\nAgent\tReview')
        wire=self.roundtrip(src)
        self.assertIn('\n\t0\n\t002 2',wire)
    def test_numeric_data_collision(self):
        src=doc('\tTa1 1\nAgent\tTask\n\t42\n\t02 1\n\t\\42\n\t\\\\anything')
        val=self.roundtrip(src)
        self.assertIn('\t\\42',val)
        self.assertIn('\t\\02 1',val)
        self.assertIn('\t\\\\42',val)
        self.roundtrip(src,prefix=False)
    def test_literal_dollar_manifest_only_first_row(self):
        src=doc('\tTa1 1\n$0\t$1\t$^^^^\t$\n\tTa2 1\n$5\t$x')
        self.roundtrip(src)
    def test_no_benefit_fallback(self):
        src=doc('\tA1 1\nA\tB\n\tB1 1\nC\tD')
        self.assertEqual(choose_transport(src).method,'native')
        self.assertEqual(choose_transport(src).text,src)
    def test_bad_dictionary_or_reference(self):
        with self.assertRaisesRegex(ValueError,'dictionary'):decode(doc('\t$2\nOne\n\tTa1 1\nA'))
        with self.assertRaisesRegex(ValueError,'reference'):decode(doc('\t$1\nValid\n\tTa1 1\nA\t^2'))
        with self.assertRaisesRegex(ValueError,'caret'):decode(doc('\tTa1 1\nA\tHello^World'))
        with self.assertRaisesRegex(ValueError,'prefix'):decode(doc('\t999\n\tTa1 1\nA'))
        with self.assertRaisesRegex(ValueError,'escape'):decode(doc('\tTa1 1\nA\t\\z'))
    def test_end_marker_and_crlf(self):
        for t in ['\tTa1 1\nA\n','\tTa1 1\r\nA\r\n\r\n\r\n','\tTa1 1\nA\n\n\n\n']:
            with self.assertRaises(ValueError):encode(t)
    def test_special_character_multilingual(self):
        src=doc('\tTa1 1\n私は\tWhat\t今\tIDE1.0\t文書を\tHTTP/2\n学生\t\t\t\t確認する\nです。\n\tTb1 1\n저는\tOAuth2Token\tNow\tGateway\t검증합니다.\t🇯🇵')
        self.roundtrip(src,['IDE1.0','Gateway'])
    def test_fuzz(self):
        r=random.Random(9801)
        alphabet=string.ascii_letters+string.digits+' $^\\!{}:\'".?=<>[]日本語'
        for _ in range(180):
            vals=[''.join(r.choice(alphabet) for i in range(r.randrange(0,24))) for _ in range(4)]
            src=doc('\tTask001 1\n'+'\t'.join(vals)+'\n\tTask002 1\n'+'\t'.join(vals))
            for c in candidates(src).values():self.assertEqual(decode(c.text),src)
    def test_output_limit(self):
        src=doc('\tTask00001 1\nA\t'+'XX'*6000+'\n\tTask00002 1\nB\t'+'XX'*6000)
        self.roundtrip(src,['XX'*6000])

if __name__=='__main__':unittest.main()
