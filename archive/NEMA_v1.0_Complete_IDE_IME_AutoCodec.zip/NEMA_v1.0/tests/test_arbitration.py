import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'compression'))
from arbitration import Arbiter
class TestOwnership(unittest.TestCase):
 def test_ime_default(self):
  x=Arbiter();self.assertEqual(x.owner(),'IME_AUTO')
 def test_ide_manual_preempts_ime_then_restores(self):
  x=Arbiter();x.begin_manual(0);self.assertEqual(x.owner(),'IDE_MANUAL')
  with self.assertRaises(RuntimeError):x.commit_ime()
  x.end_manual(0);self.assertEqual(x.owner(),'IME_AUTO')
 def test_cannot_preempt_composition(self):
  x=Arbiter(composition=True)
  with self.assertRaisesRegex(RuntimeError,'composition'):x.begin_manual(0)
 def test_stale_version(self):
  x=Arbiter();x.commit_ime()
  with self.assertRaisesRegex(RuntimeError,'stale'):x.begin_manual(0)
 def test_no_ime_does_not_imply_ide_auto(self):
  x=Arbiter(ime_present=False);self.assertEqual(x.owner(),'NONE')
 def test_double_manual_rejected(self):
  x=Arbiter();x.begin_manual(0)
  with self.assertRaises(RuntimeError):x.begin_manual(0)
 def test_manual_end_invalid_revision(self):
  x=Arbiter();x.begin_manual(0);x.revision=1
  with self.assertRaisesRegex(RuntimeError,'stale'):x.end_manual(0)
