# NEMA training red-green and adversarial checklist

- [ ] Red: What text resembling a domain header is incorrectly read as a new domain.
- [x] Green: protected `\t Ta1 1` is parsed as literal What content.
- [ ] Red: Graph reverse direction `B<Z<C` incorrectly rendered as B → C.
- [x] Green: correct direction C → B in reference parser and human graph view.
- [ ] Red: source cell `APIKey` is silently lowercased or split.
- [x] Green: no case normalization or internal punctuation splitting.
- [ ] Red: Table continuing note is interpreted as a new record.
- [x] Green: empty X0 inherits current row in the table.
- [ ] Red: consecutive empty lines in the middle are accepted.
- [x] Green: two blank physical lines allowed only at EOF.

These are reference-parser checks. The separate JSONL SFT holdout has not been run against an external model; hence no model-accuracy claim is made.
