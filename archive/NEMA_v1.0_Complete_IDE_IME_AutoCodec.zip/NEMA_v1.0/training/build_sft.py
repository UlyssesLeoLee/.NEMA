#!/usr/bin/env python3
"""Generate deterministic, synthetic SFT and held-out evaluation JSONL.
User-specific information and actual credentials must never enter the dataset.
"""
import json,random,sys,pathlib
ROOT=pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))
from src.nema import render
out=ROOT/'training';rng=random.Random(20261106)
entries=[]
def add(topic,raw,question,answer):
 entries.append({'id':f'nema-{len(entries)+1:04d}','topic':topic,'messages':[
  {'role':'system','content':'You understand the experimental NEMA v0.9 grammar. Parse literal Tab positions, never infer structural boundaries from natural-language punctuation. Answer exactly without adding invented content.'},
  {'role':'user','content':f'{question}\n\n```nema\n{raw}```'},
  {'role':'assistant','content':answer}]})
def doc(lines):return '\n'.join(lines)+'\n\n\n'
# 5W1H, semantic atom, case, punctuation and mixed-language examples.
for i in range(70):
 user=['Claude','Argo','Codex','Hermes'][i%4];s=['Review','Inspect','Validate','Audit'][i%4];note=['APIKey=aBc9_Xy!','HTTP/2','POST /v1/login?u=42&retry=2','JSON{"mode":"Ai","key":"APIKey"}'][i%4]
 raw=doc([f'\tT{i} 1',f'{user}\t{s}\tNow\tIDE1.0\tWrite\t{note}','\t\t\t\tSample'])
 data=render(raw)[0]
 add('5w1h',raw,'Extract all six 5W1H fields and the domain revision as JSON.',json.dumps(data,ensure_ascii=False,separators=(',',':')))
for i in range(28):
 raw=doc([f'\tJ{i} 2','私は\t確認\t今日\t日本\t文書を\tAPIKey','学生\tする\t\t\t読む','です。'])
 val=render(raw)[0]
 add('japanese',raw,'Render the domain to six readable 5W1H values, preserving Japanese attachment.',json.dumps(val,ensure_ascii=False,separators=(',',':')))
for i in range(30):
 actor=['Claude','Codex','Argo'][i%3]
 raw=doc([f'\tTtable{i} 1','\tAgent\tStatus\tNote',actor+'\tReady\tThe APIKey','\t\twas verified,','\t\taccess granted.','Other\tFailed\tHTTP/2 returned','\t\t401; retry denied.'])
 add('table',raw,'Return the exact table headers and rendered rows as JSON.',json.dumps(render(raw)[0],ensure_ascii=False,separators=(',',':')))
for i in range(36):
 rel=['Reads','Writes','Responds'][i%3]
 direction=['>','<','='][i%3]
 raw=doc([f'\t>G{i} 1','A\tGateway\tAuth API','B\tStore\tDatabase',f'A{direction}E{i}{direction}B\t{rel}\tThe APIKey','\t\twas verified.'])
 val=render(raw)[0]
 add('graph',raw,'Return graph nodes and all edges with direction, edge ID, label and description as JSON.',json.dumps(val,ensure_ascii=False,separators=(',',':')))
# Explicit negative/counterfactual examples.
invalids=[
 ('\tT1 1\nA\n','Missing two fully blank physical lines at EOF.'),
 ('\t>G1 1\nA\nA>X>B\n\n\n','Edge X references undeclared node B.'),
 ('\tT1 1\nA\n\nB\n\n\n','Two blank lines can only appear at EOF, not in the middle of a domain.'),
 ('\tT1 1\n\tA\tA\n1\t2\n\n\n','Table headers are duplicated.'),
 ('\t>G1 1\nA\nB\nA>X<B\n\n\n','Graph edge direction operators do not match.'),
 ('\tT1 1\nA\n\tT1 2\nB\n\n\n','Domain ID T1 is duplicated.')]
for i in range(32):
 raw,expected=invalids[i%len(invalids)]
 add('invalid',raw,'Is this valid NEMA? If not, give the specific deterministic parser error.',expected)
# Holdout mixed by topic, but avoid same raw duplicated across train/validation: last two duplicates omitted.
seen=set();unique=[]
for x in entries:
 raw=x['messages'][1]['content'];
 if raw in seen:continue
 seen.add(raw);unique.append(x)
rng.shuffle(unique)
train=[];valid=[]
for i,x in enumerate(unique):
 (valid if i%5==0 else train).append(x)
for name,seq in [('nema_sft_train.jsonl',train),('nema_eval_holdout.jsonl',valid)]:
 (out/name).write_text(''.join(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n' for x in seq),encoding='utf-8')
print('train',len(train),'eval',len(valid),'topics',sorted({x['topic'] for x in unique}))
