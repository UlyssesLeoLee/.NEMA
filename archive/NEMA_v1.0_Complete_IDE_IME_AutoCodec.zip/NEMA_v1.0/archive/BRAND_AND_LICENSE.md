# Brand and typography notes

NEMA = Ariadne's Thread: navy labyrinth, gold guiding thread, Ariadne-inspired sculpture, abstract thread-knot icon. Assets in `brand/` and `website/assets/` are part of the generated project bundle.

Suggested font families: Inter (Latin), Noto Sans SC (Simplified Chinese), Noto Sans JP (Japanese). Their applicable SIL Open Font License 1.1 grants commercial use, subject to its terms. The website requests stylesheets online when available and has offline system fallbacks. **No font binary files are bundled or redistributed.**

There is deliberately no visible font license sentence on the marketing homepage. Document legal attribution separately when redistributed as required.

Product status: experimental format, benchmark data must not be advertised as a validated vendor-model Token advantage.
