# NEMA human authoring quick guide (English)

A domain header is **one literal Tab + ID + space + revision**. The `>` before an ID marks a Graph. The first line following a standard domain header starts at column zero for 5W1H; a leading Tab indicates a pure Table.

- **X axis:** Tab cells map to Who, What, When, Where, Why, How.
- **Y axis:** Each nonempty cell in the next physical line appends one semantic atom in the same column.
- **Text:** Never force PascalCase. Preserve acronym case, punctuation, mixed-case identifiers and API references. Language-aware rendering is a *normalized display*, not source replacement.
- **Table:** Header line starts with one Tab. Nonempty X0 starts a record; empty X0 appends to the current record.
- **Graph:** `A>X>B` means A→B with edge ID X; `A<X<B` means B→A; `A=Z=B` is undirected. Edge descriptions can continue vertically.
- **EOF:** Two completely empty physical lines terminate the document.

The parser, not an LLM, must determine all field and edge boundaries.
