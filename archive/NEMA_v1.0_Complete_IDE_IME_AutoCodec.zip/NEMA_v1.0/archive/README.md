# 历史归档

`NEMA_v0.9_complete_archive.zip` 为之前交付的三语网站、Logo、历史 v0.3–v0.9、训练语料及实测资料的冻结归档。

此 v1.0 文件夹内 `docs/CORE/` 与 `compression/` 是新的压缩传输层设计；不要将历史 `n9` 或强制 PascalCase 语法与本版混用。
