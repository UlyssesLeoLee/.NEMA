# NEMA v0.9 · 最终自审 / Red–Green 记录

## 结构和解析

- 三模式：5W1H、纯表格、Node–Edge Graph，无强制全局 `n9` 文件头。
- 领域头：1 个真实 Tab + ID + Revision；Graph 增加 `>` 作为类型标识。
- Table：领域下一行首字符 Tab 为表头模式；非空 X0 新建记录、空 X0 续写。
- Graph：`A>X>B` 方向 A→B；`B<Z<C` 方向 C→B；`A=U=C` 无向；独立 Edge ID，附加多行说明。
- 意群：每个模式使用相同 Tab/换行规则；英语缩约、日语助词、标点原样保留。
- EOF：最后一行之后两个完全空白物理行。跨域数据不必插入空行。
- 保留头部冲突：允许 `\t Ta1 1` 将它解释为 What 文字（前置空格是罕见的保护语法）。
- 参考解析器和网页展示分别测试，不把 AI 的自然语言理解当作确定性解析器。

## Red–Green 与对抗审查

1. **Red**：初期 `test_graph_only_header` 发现空 Graph 领域被接受 → **Green**：必须至少有一个 Node/Edge。
2. **Red**：图示审计时误以为 Edge Z 是正向 → **Green**：确定性断言 `B<Z<C` 为 C→B，网页实际交互检查同样通过。
3. **Red**：默认 SentencePiece 折叠 Tab 与换行，使一个和五个 Tab 产生相同 Token 计数 → **Green**：改为 `identity`、`remove_extra_whitespaces=false`、`split_by_whitespace=false` 并强制编码往返，全部重测。
4. **Red**：日语逐词写法和表格纵向拆句比位置式 YAML 更耗 Token → **Green**：提供**语义等价、保持完整意群**的对照变体，实际下降 Token；不强制切词。
5. **Red**：领域头 `\tTa1 1` 可与 What 续行混淆 → **Green**：领域头保留文法，允许极少数场景加一空格保护。

## 当前测试与限制

- Python：`python -m unittest discover -s tests -p 'test_nema.py'` — 30 项通过。
- 网页：Playwright + 系统 Chromium：桌面、手机、中日英切换、Graph、Table、5W1H、反向边检查均通过。当前环境屏蔽本地 file:// 与 localhost 的浏览器导航，所以测试程序使用**同源页面的原始 HTML/CSS/JS 与本地图片，在内存中内联并加载**，这是功能与排版测试，不是本地文件导航测试。
- Token：10 组语义等价负载、两套已训练且**保留 Tab 和换行**的 SentencePiece 代理 tokenizer。并非 GPT / Claude / Gemini 官方词表；没有直接获取商用模型 Token 账单。
- 图示 Graphviz SVG/PNG 根据实际 Graph AST 生成；SVG 仅用于展示，不作为权威数据源。
- 独立领域和版本可解析，但生产级 Agent 并发存储、事务、锁与资源冲突检查**未实现**，仅在架构文档中规定了接口责任。
- 输入法或文本编辑器若把 Tab 自动换成空格将改变结构，应作为客户端的格式错误处理。

## 商用与字体

站点 CSS 使用 Inter、Noto Sans SC、Noto Sans JP 在线字体请求和离线回退；品牌首页不写字体许可说明；文件包中不含字体二进制。相关授权与品牌资产说明保存在 `BRAND_AND_LICENSE.md`。
