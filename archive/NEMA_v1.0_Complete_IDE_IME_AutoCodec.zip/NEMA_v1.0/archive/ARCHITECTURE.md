# NEMA v0.9 · Minimal architecture

```mermaid
flowchart TD
  A[.nema UTF-8 source] --> B[Deterministic Tab parser]
  B --> C[Domain AST: id/revision/mode]
  C --> D[5W1H / Table / Graph]
  D --> E[IDE1.0 cards, tables, SVG graph]
  D --> F[Domain/element index]
  F --> G[Argo multi-agent dispatch]
  G --> H[Patch proposal]
  H --> I{CAS + resource conflict check}
  I -->|pass| J[New revision]
  I -->|conflict| K[Reject + rebase]
```

- Parser outputs exact raw atoms plus a separate normalized human view. AI never determines field boundaries.
- Atomic persistence should use SQLite or a transactional database; the v0.9 Python reference is a read-only prototype, **not** a finished distributed CAS implementation.
- `Domain ID + revision` = task-level conflict boundary; actual source files, graph elements, and overlapping resources additionally require independent lock/conflict checks.
- Rendering uses current data; cached SVG can be discarded and regenerated without modifying canonical `.nema`.
- Structured graph data supports `>` (forward), `<` (reverse), `=` (undirected), self-loop and parallel edges.
- Text in Table / Edge descriptions uses the same vertical atomic continuation rules as 5W1H.
- User secrets should be stored in a dedicated secret manager and passed by opaque reference, not serialized as values.
- Historical versions are retained in `history/` but MUST NOT be interpreted as this version without explicit migration.
