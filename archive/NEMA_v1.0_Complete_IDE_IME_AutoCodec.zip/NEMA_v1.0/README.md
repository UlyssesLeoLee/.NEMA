# NEMA v1.0 — IDE1.0 / IME1.0 可逆压缩集成开发包

本版本将 `.nema`（可编辑、三模式二维语义文件）与 `.nemat`（可逆的 Token 友好传输形式）分离，附可执行 Python 编解码参考实现、自动共享字典/数字前缀选择器、无损回归测试、实测数据、IDE1.0 与 IME1.0 的中文实施设计（要件定义/基本+详细设计/UT、IT、ST）。

**最新补充约束**：共享字典只在首行 `TAB$N` 声明；`TAB数字` 是压缩传输中的前缀/领域索引，`^k` 为整格字典引用，字面 `^` 用 `\\^`；IME1.0 默认自动转换，IDE1.0 只有用户手动点击转换按钮才抢占。原生 `.nema` 不自动应用这些控制字符。

本包**未修改 IDE1.0/IME1.0 的仓库或实现 Windows TSF**。这两个项目的接入是待开发设计。当前经过测试的是 Python 编解码器和离线压缩成本；网站和历史资料保留前一版 v0.9 状态。

## 目录
- `docs/CORE/` NEMA 压缩协议要件/基本/详细/通信设计。
- `docs/IDE1.0/` IDE1.0 接入设计与 UT/IT/ST。
- `docs/IME1.0/` IME1.0 输入法自动转换设计与 UT/IT/ST。
- `compression/` Python 参考 codec 和 CLI。
- `tests/` 回归与仲裁模型测试。
- `bench/` 完整可复现的本地 SentencePiece 代理基准与 fixtures。
- `training/` 给大模型的专项训练指南与示例。
- `website/` 中英日三语静态网站（沿用 v0.9 并附 v1 压缩文档入口）。
- `archive/` 历史 v0.9 正式归档与旧版资源说明。

## 快速运行
```sh
python -m unittest discover -s tests -v
python bench/bench.py
python compression/cli.py inspect samples/twelve_agents.nema --model bench/models/neutral_bpe.model
python compression/cli.py encode samples/twelve_agents.nema output.nemat
python compression/cli.py decode output.nemat recovered.nema
```
`choose` 返回 native 时应使用 `.nema` 后缀；返回 transport 时必须用 `.nemat` 后缀。所有 `.nema` 示例以 `LF LF LF` 结束：即最后有效行之后两个空白物理行。

## 重要注意
- 本地测试分词器保持 Tab 和换行，但不是任何实际服务商的官方 tokenizer；实际 API 账单的 Token 节省率还需要连接目标模型的 tokenizer 测试。
- 运行前先审核 Graph ID、CAS 与密钥引用；不要将此实验编码器直接作为生产安全边界。
